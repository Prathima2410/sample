using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CustomerService.Models{

public class Complaint
{
    [Key]
    public int ComplaintId { get; set; }

    [ForeignKey("User")]
    public int UserId { get; set; }
    public User User { get; set; }

    [Required]
    [MaxLength(255)]
    public string UserComplaint { get; set; }

    [ForeignKey("Status")]
    public int StatusId { get; set; }

   

    
    public Status Status { get; set; }
}
}
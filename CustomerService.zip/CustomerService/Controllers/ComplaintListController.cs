using CustomerService.Data;
using CustomerService.Models;
using CustomerService.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;



public class ComplaintListController : Controller
{
    
     private readonly ApplicationDbContext _context;
    private readonly ILogger<ComplaintController> _logger;
       private readonly IHttpContextAccessor _httpContextAccessor;

    public ComplaintListController(ApplicationDbContext context, ILogger<ComplaintController> logger,IHttpContextAccessor httpContextAccessor)
    {
        _context = context;
        _logger = logger;
        _httpContextAccessor = httpContextAccessor;
    }
    
[Authorize(Roles = "Admin")]

 public IActionResult ComplaintList()
    {
        

        try{
             var jwtToken = _httpContextAccessor.HttpContext.Session.GetString("JwtToken");
             _logger.LogInformation("Fetching complaint list.");
            if(jwtToken!=null)
             {
               var complaints = _context.Complaints
               // .Include(c => c.User) // Include related user information if needed
              // .Include(c => c.Status) // Include related status information if needed
               .ToList();

                return View(complaints);
        }
         return RedirectToAction("Login", "Auth");
    }
      catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred while fetching complaints.");
            return StatusCode(500); // Or handle the error accordingly
        }
    }

    [HttpPost]

    public async Task<IActionResult> CreateComplaint(Complaint complaint)
     
    {
      try
        {
            _logger.LogInformation("Creating complaint.");

        var user = await _context.User.FirstOrDefaultAsync(u => u.UserId == complaint.UserId);

        if (user!=null)
        {
            // Assuming StatusId is set to 1 for "Raised" status
            complaint.StatusId = 1; // Set the status to "Raised" here

            _context.Complaints.Add(complaint);
            await _context.SaveChangesAsync();
           _logger.LogInformation("Complaint created successfully.");
            return RedirectToAction("ComplaintList", "Complaint"); // Redirect to a success page or any other page
        }
         _logger.LogWarning("User not found while creating complaint.");
        return View("ComplaintForm", complaint); // Return to the form if validation fails
    }
     catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while creating complaint.");
            return StatusCode(500); // Or handle the error accordingly
        }
    
  }
}
using CustomerService.Data;
using CustomerService.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging; 
using Microsoft.AspNetCore.Http; 

public class AuthController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly IConfiguration _configuration;
    private readonly PasswordService _passwordService;
     private readonly ILogger<AuthController> _logger; 

    public AuthController(ApplicationDbContext context, IConfiguration configuration,PasswordService passwordService,  ILogger<AuthController> logger)
    {
        _context = context;
        _configuration = configuration;
        _passwordService=passwordService;
         _logger = logger;
    }

    public IActionResult Login()
    {
         _logger.LogInformation("Login page accessed.");
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Login(User model)
    {
        try
        {

        
        var user = await _context.User.FirstOrDefaultAsync(u => u.Username == model.Username);

    //    var pass= _passwordService.HashPassword(model.PasswordHash); 
     
        if (user == null || !_passwordService.VerifyPassword(user.PasswordHash, model.PasswordHash))
        {
            _logger.LogWarning("Invalid username or password for user: {Username}", model.Username);
            return Unauthorized(); // Invalid username or password
        }

        var userRole = user.Role; // Get the user's role
        var token = GenerateJwtToken(model.Username, userRole);
        HttpContext.Session.SetString("JwtToken", token);
        if (userRole == "User")
        {
            return RedirectToAction("ComplaintForm", "Complaint");
        }
        else
        {
            return RedirectToAction("ComplaintList", "Complaint");
        }
      
        // return RedirectToAction("ComplaintForm", "Complaint");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while processing login for user: {Username}", model.Username);
            return StatusCode(500); // Or handle the error accordingly
        }

    }

    private string GenerateJwtToken(string username, string role)
    {
        var tokenKey = _configuration["JwtSettings:Key"];
        var tokenIssuer = _configuration["JwtSettings:Issuer"];
        var tokenAudience = _configuration["JwtSettings:Audience"];

        var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(tokenKey));
        var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, username),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new Claim(ClaimTypes.Role, role)
        };

        var token = new JwtSecurityTokenHandler().CreateJwtSecurityToken(
            issuer: tokenIssuer,
            audience: tokenAudience,
            new ClaimsIdentity(claims),
            expires: DateTime.UtcNow.AddMinutes(100), // Set token expiration
            signingCredentials: credentials
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}

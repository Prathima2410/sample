namespace CustomerService.Services
{
    public class PasswordService
    {
       
       public bool VerifyPassword(string hashedPassword, string password)
       {
        return BCrypt.Net.BCrypt.Verify(password,hashedPassword);
       }
        public string HashPassword(string password)
        {
            // Generate a salt with a work factor of 10
            string salt = BCrypt.Net.BCrypt.GenerateSalt(10);
            // Hash the password using the salt
            string hash = BCrypt.Net.BCrypt.HashPassword(password, salt);
            
            return hash;
        }
    }
}
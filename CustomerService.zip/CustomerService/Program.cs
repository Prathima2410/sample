using System.Data;
using CustomerService.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.Text;
using CustomerService.Services;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddScoped<PasswordService>();

builder.Services.AddDbContext<ApplicationDbContext>(

options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))

);

// Configure JWT authentication
var tokenKey = builder.Configuration["JwtSettings:Key"]; // Replace with your secret key
var tokenIssuer = builder.Configuration["JwtSettings:Issuer"];
var tokenAudience = builder.Configuration["JwtSettings:Audience"];

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidIssuer = tokenIssuer,
        ValidateAudience = true,
        ValidAudience = tokenAudience,
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(tokenKey)),
        RequireExpirationTime = true,
        ValidateLifetime = true,
        ClockSkew = TimeSpan.Zero
    };
});
//  builder.Services.AddAuthorization(options =>
//     {
//         options.AddPolicy("UserPolicy", policy => policy.RequireRole("User"));
//         options.AddPolicy("AdminPolicy", policy => policy.RequireRole("Admin"));
//     });
builder.Services.AddSession(options =>
{
    options.Cookie.Name = "JwtToken";
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Adjust as needed
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// adding serilog
var _logger = new LoggerConfiguration()
  .ReadFrom.Configuration(builder.Configuration)
  .Enrich.FromLogContext()
  .CreateLogger();

// builder.Logging.ClearProviders(); //if its enabled console loggings won't work
builder.Logging.AddSerilog(_logger);
builder.Services.AddHttpContextAccessor();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// app.Use(async (context, next) =>
// {
//     var jwtToken = context.Session.GetString("JwtToken");

//     if (!string.IsNullOrEmpty(jwtToken))
//     {
//         // Validate and set user claims using the token
//         // ...

//         await next();
//     }
//     else
//     {
//         // Redirect to login or handle unauthorized access
//         context.Response.Redirect("/Auth/Login");
//     }
// });

app.UseAuthentication();

app.UseAuthorization();

// Use session middleware
app.UseSession();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Auth}/{action=Login}/{id?}");

app.Run();

